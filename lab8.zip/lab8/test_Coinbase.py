import unittest
from Coinbase import get_historical_data, get_available_products
import sys
sys.path.append(r'C:\Users\aloha\Desktop\lab8')

class TestCoinbaseLoader(unittest.TestCase):
    def test_get_historical_data(self):
        # Перевірка, чи повертається дані для вказаного продукту
        data = get_historical_data('BTC-USD', '2024-01-01', '2024-01-02', 3600)
        self.assertIsNotNone(data)
    
    def test_get_available_products(self):
        # Перевірка, чи правильно ініціалізується список доступних продуктів
        products = get_available_products()
        self.assertIsInstance(products, list)
        self.assertTrue(len(products) > 0)
    
    def test_invalid_product(self):
        # Перевірка, чи обробляється неправильний запит до API
        data = get_historical_data('INVALID-PRODUCT', '2024-01-01', '2024-01-02', 3600)
        self.assertIsNone(data)

if __name__ == '__main__':
    unittest.main()
